// ============================================================
// CloudTwin Nexus — TypeScript Type Definitions
// ============================================================

export type Status = 'healthy' | 'warning' | 'critical' | 'failed' | 'offline' | 'unknown'
export type Severity = 'critical' | 'high' | 'medium' | 'low' | 'info'
export type ComponentType =
  | 'service'
  | 'pod'
  | 'node'
  | 'container'
  | 'database'
  | 'cache'
  | 'load_balancer'
  | 'gateway'
  | 'storage'
  | 'network'
  | 'region'
  | 'cluster'
  | 'user'

export interface Project {
  id: string
  name: string
  description: string
  cloudProvider: string
  status: Status
  createdAt: string
}

export interface Component {
  id: string
  projectId: string
  name: string
  type: ComponentType
  status: Status
  region?: string
  cpu: number
  memory: number
  requestRate: number
  errorRate: number
  latency: number
  replicas: number
  cost: number
  parentId?: string
  metadata?: Record<string, unknown>
}

export interface Dependency {
  id: string
  sourceId: string
  targetId: string
  type: string
  protocol: string
  avgLatencyMs: number
  trafficRps: number
}

export interface MetricPoint {
  time: string
  value: number
}

export interface MetricSeries {
  name: string
  data: MetricPoint[]
  color?: string
}

export interface DashboardData {
  healthScore: number
  cpuAvg: number
  memoryAvg: number
  networkIn: number
  networkOut: number
  requestRate: number
  errorRate: number
  avgLatency: number
  activeServices: number
  podCount: number
  containerCount: number
  nodeCount: number
  estimatedCost: number
  sla: number
  securityScore: number
  riskScore: number
  status: Status
}

export interface TopologyNode {
  id: string
  type: ComponentType
  name: string
  status: Status
  metrics: {
    cpu: number
    memory: number
    requestRate: number
    latency: number
    errorRate: number
  }
  position: { x: number; y: number }
}

export interface TopologyEdge {
  id: string
  source: string
  target: string
  latencyMs: number
  trafficRps: number
  protocol: string
}

export interface SimulationMutation {
  type: 'traffic_multiplier' | 'kill_component' | 'add_replica' | 'remove_replica' |
        'increase_latency' | 'add_cache' | 'increase_cpu' | 'increase_memory' |
        'add_region' | 'network_failure' | 'region_failure'
  componentId?: string
  value?: number
}

export interface SimulationScenario {
  name: string
  mutations: SimulationMutation[]
}

export interface ComponentSimResult {
  id: string
  name: string
  statusBefore: Status
  statusAfter: Status
  latencyBefore: number
  latencyAfter: number
  cpuBefore: number
  cpuAfter: number
  errorRateBefore: number
  errorRateAfter: number
}

export interface SimulationResult {
  id: string
  name: string
  status: 'completed' | 'running' | 'failed'
  overallHealthBefore: Status
  overallHealthAfter: Status
  latencyBefore: number
  latencyAfter: number
  slaBefore: number
  slaAfter: number
  costBefore: number
  costAfter: number
  requestRateBefore: number
  requestRateAfter: number
  affectedUsersPercent: number
  bottleneck: string
  components: ComponentSimResult[]
  recommendations: string[]
  timestamp: string
}

export interface AnalysisFinding {
  id: string
  category: 'security' | 'cost' | 'performance' | 'reliability' | 'architecture'
  severity: Severity
  title: string
  description: string
  affectedComponents: string[]
  impact: string
  recommendation: string
  estimatedImprovement?: Record<string, string>
  status: 'open' | 'acknowledged' | 'resolved' | 'ignored'
}

export interface FailurePrediction {
  id: string
  componentId: string
  componentName: string
  predictionType: 'failure' | 'degradation' | 'saturation'
  severity: Severity
  predictedIssue: string
  estimatedTime: string
  confidence: number
  cause: string
  trendData: number[]
  status: 'active' | 'resolved' | 'expired'
}

export interface Architecture {
  id: string
  name: string
  description: string
  costMonthly: number
  estimatedSla: number
  avgLatencyMs: number
  securityScore: number
  scalabilityScore: number
  complexityScore: number
  resilienceScore: number
  cloudProvider: string
  isCurrent: boolean
}

export interface OptimizationConstraints {
  maxCostMonthly: number
  minSla: number
  maxLatencyMs: number
  expectedUsers: number
}

export interface OptimizationCandidate {
  name: string
  cost: number
  sla: number
  latency: number
  verdict: 'PASS' | 'FAIL' | 'OVER_BUDGET'
  details: string
}

export interface HealthReport {
  id: string
  title: string
  overallScore: number
  scores: {
    performance: number
    security: number
    reliability: number
    costEfficiency: number
    scalability: number
  }
  findings: AnalysisFinding[]
  simulations: SimulationResult[]
  predictions: FailurePrediction[]
  timestamp: string
}

export interface KubernetesNode {
  id: string
  name: string
  status: Status
  cpu: number
  cpuCapacity: number
  memory: number
  memoryCapacity: number
  podCount: number
  podCapacity: number
  conditions: string[]
}

export interface KubernetesPod {
  id: string
  name: string
  namespace: string
  nodeName: string
  status: string
  restarts: number
  cpu: number
  memory: number
  age: string
  containers: number
}

export interface NetworkPath {
  id: string
  source: string
  target: string
  hops: { name: string; latencyMs: number }[]
  totalLatencyMs: number
  protocol: string
}

export interface GeoRegion {
  id: string
  name: string
  code: string
  coordinates: [number, number]
  latency: number
  availability: number
  traffic: number
  errorRate: number
  status: Status
}

export interface CostBreakdown {
  service: string
  cost: number
  percentage: number
  trend: 'up' | 'down' | 'stable'
  utilization: number
}

export interface CostOptimization {
  id: string
  title: string
  currentCost: number
  optimizedCost: number
  savings: number
  component: string
  reason: string
  action: string
}
