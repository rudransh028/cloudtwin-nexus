import React from 'react';
import { Activity, MemoryStick, ArrowUpDown, Timer, AlertCircle, CheckCircle, Wallet, Shield } from 'lucide-react';
import { HealthScore } from '@/components/dashboard/HealthScore';
import { InfrastructureSummary } from '@/components/dashboard/InfrastructureSummary';
import { AlertsList } from '@/components/dashboard/AlertsList';
import { AreaChart } from '@/components/charts/AreaChart';
import { LineChart } from '@/components/charts/LineChart';
import { 
  mockRequestRateHistory, 
  mockLatencyHistory, 
  mockCpuHistory, 
  mockMemoryHistory, 
  mockErrorRateHistory,
  mockPredictions
} from '@/data/mockData';

// Helper component for small metric cards
const MetricCard = ({ title, value, icon: Icon, trend, status, desc }: any) => {
  const getStatusColor = () => {
    if (status === 'healthy') return 'text-emerald-400';
    if (status === 'warning') return 'text-amber-400';
    if (status === 'critical') return 'text-rose-400';
    return 'text-blue-400';
  };

  return (
    <div className="bg-slate-800/50 border border-slate-700/50 backdrop-blur-sm rounded-xl p-5 shadow-lg shadow-slate-900/20">
      <div className="flex items-center justify-between mb-4">
        <h4 className="text-sm font-medium text-slate-400">{title}</h4>
        <div className={`p-2 bg-slate-900/50 rounded-lg ${getStatusColor()}`}>
          <Icon className="w-5 h-5" />
        </div>
      </div>
      <div className="flex items-end justify-between">
        <div>
          <div className="text-2xl font-bold text-slate-100">{value}</div>
          {desc && <div className="text-xs text-slate-500 mt-1">{desc}</div>}
        </div>
        {trend && (
          <div className={`text-xs font-medium px-2 py-1 rounded-md ${
            trend === 'up' ? 'text-emerald-400 bg-emerald-500/10' : 
            trend === 'down' ? 'text-rose-400 bg-rose-500/10' : 
            'text-slate-400 bg-slate-700/50'
          }`}>
            {trend === 'up' ? '↑' : trend === 'down' ? '↓' : '→'}
          </div>
        )}
      </div>
    </div>
  );
};

export default function DashboardPage() {
  // Combine CPU and Memory data for dual chart
  const systemData = mockCpuHistory.map((cpu, i) => ({
    time: cpu.time,
    cpu: cpu.value,
    memory: mockMemoryHistory[i]?.value || 0
  }));

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-100">Cloud Overview</h1>
        <p className="text-slate-400 mt-2">Real-time monitoring and architecture intelligence</p>
      </div>

      {/* Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <HealthScore />
        </div>
        <div className="lg:col-span-2 grid grid-cols-2 gap-4">
          <MetricCard title="CPU Usage" value="67%" icon={Activity} trend="up" status="warning" desc="Avg across cluster" />
          <MetricCard title="Memory Usage" value="72%" icon={MemoryStick} trend="up" status="warning" desc="Avg across cluster" />
          <MetricCard title="Request Rate" value="4.8K/min" icon={ArrowUpDown} trend="stable" status="info" desc="Total traffic" />
          <MetricCard title="Avg Latency" value="95ms" icon={Timer} trend="down" status="healthy" desc="p95 response time" />
        </div>
      </div>

      {/* Row 2 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard title="Error Rate" value="0.3%" icon={AlertCircle} status="healthy" desc="Last 24 hours" />
        <MetricCard title="SLA" value="99.87%" icon={CheckCircle} status="healthy" desc="Current month" />
        <MetricCard title="Est. Cost" value="₹18,500/mo" icon={Wallet} status="info" desc="AWS bill projection" />
        <MetricCard title="Security Score" value="78/100" icon={Shield} status="warning" desc="3 open findings" />
      </div>

      {/* Row 3 - Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-slate-800/50 border border-slate-700/50 backdrop-blur-sm rounded-xl p-5 shadow-lg">
          <h3 className="text-sm font-semibold text-slate-200 mb-4">Request Rate (24h)</h3>
          <AreaChart data={mockRequestRateHistory} color="#06b6d4" gradientId="requestRateGradient" name="Requests/min" />
        </div>
        <div className="bg-slate-800/50 border border-slate-700/50 backdrop-blur-sm rounded-xl p-5 shadow-lg">
          <h3 className="text-sm font-semibold text-slate-200 mb-4">Latency (p50, p95, p99)</h3>
          <LineChart 
            data={mockLatencyHistory} 
            lines={[
              { dataKey: 'p50', color: '#10b981', name: 'p50 (ms)' },
              { dataKey: 'p95', color: '#f59e0b', name: 'p95 (ms)' },
              { dataKey: 'p99', color: '#ef4444', name: 'p99 (ms)' }
            ]} 
          />
        </div>
      </div>

      {/* Row 4 - Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-slate-800/50 border border-slate-700/50 backdrop-blur-sm rounded-xl p-5 shadow-lg">
          <h3 className="text-sm font-semibold text-slate-200 mb-4">System Resources (%)</h3>
          <LineChart 
            data={systemData} 
            lines={[
              { dataKey: 'cpu', color: '#8b5cf6', name: 'CPU Usage' },
              { dataKey: 'memory', color: '#3b82f6', name: 'Memory Usage' }
            ]} 
          />
        </div>
        <div className="bg-slate-800/50 border border-slate-700/50 backdrop-blur-sm rounded-xl p-5 shadow-lg">
          <h3 className="text-sm font-semibold text-slate-200 mb-4">Error Rate (%)</h3>
          <AreaChart data={mockErrorRateHistory} color="#f43f5e" gradientId="errorRateGradient" name="Error Rate" />
        </div>
      </div>

      {/* Row 5 - Alerts and Predictions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="h-[400px]">
          <AlertsList />
        </div>
        <div className="bg-slate-800/50 border border-slate-700/50 backdrop-blur-sm rounded-xl p-6 shadow-lg h-[400px] flex flex-col">
          <div className="mb-4">
            <h3 className="text-lg font-semibold text-slate-100">AI Predictions</h3>
            <p className="text-sm text-slate-400">Forecasting and optimization suggestions</p>
          </div>
          <div className="flex-1 overflow-y-auto space-y-4 pr-2 custom-scrollbar">
            {mockPredictions.map((pred) => (
              <div key={pred.id} className="bg-slate-900/50 border border-slate-700 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-sm font-medium text-slate-200">{pred.title}</h4>
                  <span className={`text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full border ${
                    pred.impact === 'High' ? 'bg-rose-500/10 text-rose-400 border-rose-500/20' :
                    pred.impact === 'Medium' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' :
                    'bg-blue-500/10 text-blue-400 border-blue-500/20'
                  }`}>
                    {pred.impact} Impact
                  </span>
                </div>
                <p className="text-sm text-slate-400 mb-3">{pred.description}</p>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded">
                    {pred.confidence}% Confidence
                  </span>
                  <span className="text-slate-500">
                    Est. {new Date(pred.estimatedTime).toLocaleDateString()}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Row 6 */}
      <div>
        <InfrastructureSummary />
      </div>
    </div>
  );
}
