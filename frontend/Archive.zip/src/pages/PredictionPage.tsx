import React from 'react';
import { Lightbulb, AlertCircle, Clock, TrendingUp } from 'lucide-react';
import { mockPredictions } from '@/data/mockData';
import { cn } from '@/lib/utils';

export default function PredictionPage() {
  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-slate-100 flex items-center gap-2">
          <Lightbulb className="text-amber-400" />
          AI Predictions
        </h1>
        <p className="text-slate-400 text-sm mt-1">Forecasted issues and capacity warnings based on historical trends.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {mockPredictions.map((pred) => (
          <div key={pred.id} className="bg-slate-800 rounded-xl p-5 border border-slate-700 shadow-sm hover:border-slate-600 transition-colors">
            <div className="flex justify-between items-start mb-4">
              <div className={cn(
                "px-2.5 py-1 rounded-full text-xs font-medium uppercase",
                pred.severity === 'high' ? 'bg-red-500/20 text-red-400' :
                pred.severity === 'medium' ? 'bg-amber-500/20 text-amber-400' :
                'bg-blue-500/20 text-blue-400'
              )}>
                {pred.severity} Severity
              </div>
              <div className="flex items-center gap-1 text-xs text-slate-400 bg-slate-900/50 px-2 py-1 rounded">
                <TrendingUp size={12} className="text-cyan-400" /> {pred.confidence}% confidence
              </div>
            </div>
            
            <h3 className="text-lg font-medium text-slate-200 mb-2">{pred.title}</h3>
            <p className="text-sm text-slate-400 mb-4">{pred.description}</p>
            
            <div className="flex items-center justify-between pt-4 border-t border-slate-700">
              <div className="flex items-center gap-2 text-sm text-slate-300">
                <Clock size={16} className="text-slate-500" />
                ETA: {pred.eta}
              </div>
              <button className="text-sm text-cyan-400 hover:text-cyan-300 font-medium">
                View Details
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
