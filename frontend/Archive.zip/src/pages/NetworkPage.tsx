import React from 'react';
import { Network, Activity, ArrowRight } from 'lucide-react';
import { mockNetworkPaths } from '@/data/mockData';

export default function NetworkPage() {
  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-slate-100 flex items-center gap-2">
          <Network className="text-purple-500" />
          Network Topology
        </h1>
        <p className="text-slate-400 text-sm mt-1">Cross-region latency and traffic routing paths.</p>
      </div>

      <div className="bg-slate-800 rounded-xl border border-slate-700 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-700">
          <h3 className="text-lg font-medium text-slate-200 flex items-center gap-2">
            <Activity size={18} className="text-slate-400" /> Critical Paths
          </h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-400">
            <thead className="text-xs text-slate-500 uppercase bg-slate-900/50">
              <tr>
                <th className="px-4 py-3">Source Region</th>
                <th className="px-4 py-3"></th>
                <th className="px-4 py-3">Target Region</th>
                <th className="px-4 py-3">Latency</th>
                <th className="px-4 py-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {mockNetworkPaths.map(path => (
                <tr key={path.id} className="hover:bg-slate-800/50 transition-colors">
                  <td className="px-4 py-3 text-slate-300 font-medium">{path.source}</td>
                  <td className="px-4 py-3 text-slate-600"><ArrowRight size={16} /></td>
                  <td className="px-4 py-3 text-slate-300 font-medium">{path.target}</td>
                  <td className="px-4 py-3">
                    <span className={path.latency > 100 ? 'text-amber-400' : 'text-emerald-400'}>
                      {path.latency}ms
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${path.status === 'optimal' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'}`}>
                      {path.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      
      <div className="bg-slate-800/50 rounded-xl p-8 border border-slate-700 text-center flex flex-col items-center justify-center">
        <Network size={48} className="text-slate-600 mb-3" />
        <h3 className="text-lg font-medium text-slate-300">Advanced Network Map</h3>
        <p className="text-sm text-slate-500 mt-2">VPC peering and Transit Gateway visualization coming in next update.</p>
      </div>
    </div>
  );
}
