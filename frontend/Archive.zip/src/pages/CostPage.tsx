import React from 'react';
import { DollarSign, TrendingDown, Lightbulb } from 'lucide-react';
import { mockCostBreakdown, mockCostOptimizations } from '@/data/mockData';

export default function CostPage() {
  const totalCost = mockCostBreakdown.reduce((sum, item) => sum + item.cost, 0);

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-slate-100 flex items-center gap-2">
          <DollarSign className="text-emerald-400" />
          FinOps & Cost
        </h1>
        <p className="text-slate-400 text-sm mt-1">Cloud spend analysis and optimization recommendations.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1 bg-slate-800 rounded-xl p-6 border border-slate-700 shadow-sm flex flex-col justify-center">
          <h3 className="text-sm font-medium text-slate-400 mb-1">Total Monthly Cost</h3>
          <div className="text-4xl font-bold text-slate-100 mb-2">${totalCost.toLocaleString()}</div>
          <div className="flex items-center gap-1 text-sm text-emerald-400">
            <TrendingDown size={16} /> 4.2% vs last month
          </div>
        </div>

        <div className="md:col-span-2 bg-slate-800 rounded-xl p-6 border border-slate-700 shadow-sm">
          <h3 className="text-lg font-medium text-slate-200 mb-4">Spend by Category</h3>
          <div className="space-y-4">
            {mockCostBreakdown.map(item => (
              <div key={item.category}>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-slate-300">{item.category}</span>
                  <span className="text-slate-400">${item.cost.toLocaleString()}</span>
                </div>
                <div className="h-2 bg-slate-900 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-cyan-500 rounded-full" 
                    style={{ width: `${(item.cost / totalCost) * 100}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-slate-800 rounded-xl p-6 border border-slate-700 shadow-sm">
        <h3 className="text-lg font-medium text-slate-200 mb-4 flex items-center gap-2">
          <Lightbulb size={20} className="text-amber-400" /> Optimization Opportunities
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {mockCostOptimizations.map(opt => (
            <div key={opt.id} className="bg-slate-900/50 p-4 rounded-lg border border-slate-800 flex justify-between items-center">
              <div>
                <h4 className="text-sm font-medium text-slate-200">{opt.title}</h4>
                <p className="text-xs text-slate-400 mt-1">{opt.description}</p>
              </div>
              <div className="text-right">
                <div className="text-lg font-semibold text-emerald-400">-${opt.savings}/mo</div>
                <button className="mt-2 text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 px-3 py-1 rounded border border-slate-700 transition-colors">
                  Apply
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
