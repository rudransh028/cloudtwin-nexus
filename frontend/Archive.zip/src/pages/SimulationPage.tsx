import React, { useState } from 'react';
import { Play, TrendingDown, DollarSign, Activity, Users, AlertTriangle } from 'lucide-react';
import { mockSimulationResults } from '@/data/mockData';
import { cn } from '@/lib/utils';

export default function SimulationPage() {
  const [trafficMultiplier, setTrafficMultiplier] = useState(1);
  const result = mockSimulationResults[0]; // Just showing the first one as default
  
  return (
    <div className="h-full flex flex-col p-6 space-y-6 overflow-y-auto">
      <div>
        <h1 className="text-2xl font-semibold text-slate-100">What-If Simulation Lab</h1>
        <p className="text-slate-400 text-sm mt-1">Simulate traffic spikes, component failures, and architecture changes.</p>
      </div>

      <div className="flex gap-6 flex-col lg:flex-row">
        {/* Left Panel: Scenario Builder */}
        <div className="w-full lg:w-1/3 space-y-6">
          <div className="bg-slate-800 rounded-xl p-5 border border-slate-700 shadow-sm">
            <h2 className="text-lg font-medium text-slate-200 mb-4">Scenario Builder</h2>
            
            <div className="space-y-5">
              <div>
                <label className="text-sm text-slate-300 font-medium block mb-3">Traffic Multiplier</label>
                <input 
                  type="range" 
                  min="1" max="100" 
                  value={trafficMultiplier} 
                  onChange={(e) => setTrafficMultiplier(Number(e.target.value))}
                  className="w-full accent-cyan-500"
                />
                <div className="flex justify-between text-xs text-slate-500 mt-2">
                  <span>1x</span>
                  <span>10x</span>
                  <span>50x</span>
                  <span>100x</span>
                </div>
                <div className="mt-2 text-sm text-cyan-400 font-medium">Current: {trafficMultiplier}x Traffic</div>
              </div>

              <div>
                <label className="text-sm text-slate-300 font-medium block mb-3">Inject Failures</label>
                <div className="grid grid-cols-2 gap-2">
                  {['Kill API', 'Kill Database', 'Kill Redis', 'Kill Node', 'Network Failure', 'Region Failure'].map(f => (
                    <label key={f} className="flex items-center gap-2 text-sm text-slate-400 hover:text-slate-200 cursor-pointer">
                      <input type="checkbox" className="rounded bg-slate-900 border-slate-700 text-cyan-500 focus:ring-cyan-500 focus:ring-offset-slate-800" />
                      {f}
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-sm text-slate-300 font-medium block mb-3">Modify Infrastructure</label>
                <div className="flex flex-wrap gap-2">
                  {['Add API Replica', 'Add DB Replica', 'Add Cache', 'Increase CPU', 'Increase Memory'].map(m => (
                    <button key={m} className="px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-slate-300 hover:bg-slate-700 transition-colors">
                      + {m}
                    </button>
                  ))}
                </div>
              </div>

              <button className="w-full mt-4 bg-cyan-600 hover:bg-cyan-500 text-white font-medium py-2.5 rounded-lg flex items-center justify-center gap-2 transition-colors shadow-lg shadow-cyan-900/50">
                <Play size={18} />
                Run Simulation
              </button>
            </div>
          </div>
        </div>

        {/* Right Panel: Results */}
        <div className="w-full lg:w-2/3 space-y-6">
          <div className="bg-slate-800 rounded-xl p-5 border border-slate-700 shadow-sm">
            <h2 className="text-lg font-medium text-slate-200 mb-4">Simulation Results: Black Friday Spike</h2>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-800">
                <div className="flex items-center gap-2 text-slate-400 text-sm mb-2"><Activity size={16}/> Health</div>
                <div className="flex items-center gap-2">
                  <span className="text-emerald-400 font-medium">Healthy</span>
                  <span className="text-slate-500">→</span>
                  <span className="text-amber-400 font-medium">Degraded</span>
                </div>
              </div>
              <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-800">
                <div className="flex items-center gap-2 text-slate-400 text-sm mb-2"><TrendingDown size={16}/> Latency</div>
                <div className="flex items-center gap-2">
                  <span className="text-slate-300">95ms</span>
                  <span className="text-slate-500">→</span>
                  <span className="text-red-400 font-medium flex items-center">420ms</span>
                </div>
              </div>
              <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-800">
                <div className="flex items-center gap-2 text-slate-400 text-sm mb-2"><Users size={16}/> SLA</div>
                <div className="flex items-center gap-2">
                  <span className="text-slate-300">99.87%</span>
                  <span className="text-slate-500">→</span>
                  <span className="text-red-400 font-medium">97.4%</span>
                </div>
              </div>
              <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-800">
                <div className="flex items-center gap-2 text-slate-400 text-sm mb-2"><DollarSign size={16}/> Cost</div>
                <div className="flex items-center gap-2">
                  <span className="text-slate-300">₹18,500</span>
                  <span className="text-slate-500">→</span>
                  <span className="text-amber-400 font-medium">₹34,200</span>
                </div>
              </div>
              <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-800">
                <div className="flex items-center gap-2 text-slate-400 text-sm mb-2"><Users size={16}/> Users Affected</div>
                <div className="text-slate-200 font-medium">37% of traffic</div>
              </div>
              <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-800 border-l-4 border-l-red-500">
                <div className="flex items-center gap-2 text-slate-400 text-sm mb-2"><AlertTriangle size={16} className="text-red-500"/> Bottleneck</div>
                <div className="text-red-400 font-medium">PostgreSQL Primary</div>
              </div>
            </div>

            <div className="mb-6">
              <h3 className="text-sm font-medium text-slate-300 mb-3">Component Impact</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm text-slate-400">
                  <thead className="text-xs text-slate-500 uppercase bg-slate-900/50">
                    <tr>
                      <th className="px-4 py-3 rounded-tl-lg">Component</th>
                      <th className="px-4 py-3">Before Status</th>
                      <th className="px-4 py-3">After Status</th>
                      <th className="px-4 py-3">Before Latency</th>
                      <th className="px-4 py-3 rounded-tr-lg">After Latency</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-slate-800">
                      <td className="px-4 py-3 text-slate-300 font-medium">API Gateway</td>
                      <td className="px-4 py-3 text-emerald-400">Healthy</td>
                      <td className="px-4 py-3 text-amber-400">Degraded</td>
                      <td className="px-4 py-3">15ms</td>
                      <td className="px-4 py-3 text-red-400">120ms</td>
                    </tr>
                    <tr className="border-b border-slate-800">
                      <td className="px-4 py-3 text-slate-300 font-medium">PostgreSQL</td>
                      <td className="px-4 py-3 text-emerald-400">Healthy</td>
                      <td className="px-4 py-3 text-red-400">Critical</td>
                      <td className="px-4 py-3">45ms</td>
                      <td className="px-4 py-3 text-red-400">380ms</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div>
              <h3 className="text-sm font-medium text-slate-300 mb-3">Recommendations</h3>
              <ul className="space-y-2">
                {result.recommendations.map((rec, i) => (
                  <li key={i} className="text-sm text-slate-300 bg-slate-900/50 p-3 rounded-lg border border-slate-800 flex items-start gap-3">
                    <span className="text-cyan-500 mt-0.5">•</span> {rec}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
