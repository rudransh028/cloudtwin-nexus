import React from 'react';
import { Zap, AlertTriangle } from 'lucide-react';

export default function PerformancePage() {
  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-slate-100 flex items-center gap-2">
          <Zap className="text-yellow-400" />
          Performance Profiler
        </h1>
        <p className="text-slate-400 text-sm mt-1">End-to-end request tracing and bottleneck analysis.</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2 bg-slate-800 rounded-xl p-6 border border-slate-700 shadow-sm">
          <h3 className="text-lg font-medium text-slate-200 mb-6">Average Request Latency Waterfall</h3>
          
          <div className="space-y-4">
            <div className="relative">
              <div className="flex justify-between text-xs text-slate-400 mb-1">
                <span>User to Load Balancer</span>
                <span>15ms</span>
              </div>
              <div className="h-4 bg-slate-900 rounded-full overflow-hidden">
                <div className="h-full bg-blue-500 rounded-full" style={{ width: '15%' }}></div>
              </div>
            </div>
            
            <div className="relative">
              <div className="flex justify-between text-xs text-slate-400 mb-1">
                <span className="pl-8">Load Balancer to API Gateway</span>
                <span>10ms</span>
              </div>
              <div className="h-4 bg-slate-900 rounded-full overflow-hidden flex">
                <div style={{ width: '15%' }}></div>
                <div className="h-full bg-cyan-500 rounded-full" style={{ width: '10%' }}></div>
              </div>
            </div>

            <div className="relative">
              <div className="flex justify-between text-xs text-slate-400 mb-1">
                <span className="pl-16">API Gateway to Auth Service</span>
                <span>20ms</span>
              </div>
              <div className="h-4 bg-slate-900 rounded-full overflow-hidden flex">
                <div style={{ width: '25%' }}></div>
                <div className="h-full bg-indigo-500 rounded-full" style={{ width: '20%' }}></div>
              </div>
            </div>

            <div className="relative">
              <div className="flex justify-between text-xs text-slate-400 mb-1">
                <span className="pl-24">Auth Service to Redis Cache</span>
                <span>5ms</span>
              </div>
              <div className="h-4 bg-slate-900 rounded-full overflow-hidden flex">
                <div style={{ width: '45%' }}></div>
                <div className="h-full bg-emerald-500 rounded-full" style={{ width: '5%' }}></div>
              </div>
            </div>

            <div className="relative">
              <div className="flex justify-between text-xs text-slate-400 mb-1">
                <span className="pl-24">Auth Service to Main DB</span>
                <span>45ms (Bottleneck)</span>
              </div>
              <div className="h-4 bg-slate-900 rounded-full overflow-hidden flex">
                <div style={{ width: '45%' }}></div>
                <div className="h-full bg-amber-500 rounded-full" style={{ width: '45%' }}></div>
              </div>
            </div>
            
            <div className="flex justify-between text-xs text-slate-500 mt-4 border-t border-slate-700 pt-2">
              <span>0ms</span>
              <span>100ms Total</span>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-slate-800 rounded-xl p-5 border border-amber-500/30 shadow-sm bg-gradient-to-b from-amber-500/10 to-transparent">
            <h3 className="text-lg font-medium text-slate-200 mb-2 flex items-center gap-2">
              <AlertTriangle className="text-amber-500" size={20} /> Top Bottleneck
            </h3>
            <div className="text-xl font-semibold text-amber-400 mb-1">Database Queries</div>
            <p className="text-sm text-slate-400">Main DB accounts for 47% of total average request latency.</p>
          </div>
          
          <div className="bg-slate-800/50 rounded-xl p-5 border border-slate-700 text-center flex items-center justify-center h-32">
            <span className="text-slate-500 italic">Advanced profiling charts coming soon...</span>
          </div>
        </div>
      </div>
    </div>
  );
}
