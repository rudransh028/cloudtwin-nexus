import React from 'react';
import { FileText, Download, Calendar } from 'lucide-react';

export default function ReportsPage() {
  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-slate-100 flex items-center gap-2">
          <FileText className="text-slate-400" />
          Reports & Compliance
        </h1>
        <p className="text-slate-400 text-sm mt-1">Generate comprehensive infrastructure health reports.</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2 bg-slate-800 rounded-xl p-6 border border-slate-700 shadow-sm">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-medium text-slate-200">Recent Reports</h3>
            <button className="bg-cyan-600 hover:bg-cyan-500 text-white px-4 py-2 rounded-lg text-sm transition-colors shadow-sm">
              Generate New Report
            </button>
          </div>
          
          <div className="space-y-3">
            {[
              { name: 'Weekly Architecture Health', date: 'Oct 07, 2026', type: 'Health' },
              { name: 'SOC2 Compliance Snapshot', date: 'Oct 01, 2026', type: 'Compliance' },
              { name: 'Q3 Cost Optimization', date: 'Sep 30, 2026', type: 'FinOps' },
            ].map((report, i) => (
              <div key={i} className="bg-slate-900/50 p-4 rounded-lg border border-slate-800 flex items-center justify-between hover:bg-slate-800 transition-colors cursor-pointer">
                <div className="flex items-center gap-4">
                  <div className="bg-slate-800 p-2 rounded-lg border border-slate-700">
                    <FileText size={20} className="text-cyan-400" />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-slate-200">{report.name}</h4>
                    <div className="flex items-center gap-3 text-xs text-slate-500 mt-1">
                      <span className="flex items-center gap-1"><Calendar size={12}/> {report.date}</span>
                      <span className="bg-slate-800 px-2 py-0.5 rounded">{report.type}</span>
                    </div>
                  </div>
                </div>
                <button className="text-slate-400 hover:text-slate-200 p-2">
                  <Download size={18} />
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-slate-800 rounded-xl p-6 border border-slate-700 shadow-sm flex flex-col justify-center items-center text-center">
          <h3 className="text-sm font-medium text-slate-400 mb-4">Overall Architecture Score</h3>
          <div className="text-6xl font-bold text-emerald-400 mb-2">A-</div>
          <p className="text-sm text-slate-400">Based on security, performance, and cost efficiency metrics.</p>
        </div>
      </div>
    </div>
  );
}
