import React from 'react';
import { Container, Cpu, Server } from 'lucide-react';
import { mockKubernetesNodes, mockKubernetesPods } from '@/data/mockData';

export default function KubernetesPage() {
  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-slate-100 flex items-center gap-2">
          <Container className="text-blue-500" />
          Kubernetes Fleet
        </h1>
        <p className="text-slate-400 text-sm mt-1">Cluster nodes, workloads, and resource utilization.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {mockKubernetesNodes.map(node => (
          <div key={node.id} className="bg-slate-800 rounded-xl p-5 border border-slate-700 shadow-sm">
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center gap-2">
                <Server size={18} className="text-slate-400" />
                <h3 className="text-sm font-medium text-slate-200">{node.name}</h3>
              </div>
              <span className={`text-xs px-2 py-0.5 rounded-full ${node.status === 'Ready' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'}`}>
                {node.status}
              </span>
            </div>
            
            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-xs text-slate-400 mb-1">
                  <span>CPU ({node.cpu} cores)</span>
                  <span>{node.cpuUsage}%</span>
                </div>
                <div className="h-2 bg-slate-900 rounded-full overflow-hidden">
                  <div className={`h-full rounded-full ${node.cpuUsage > 80 ? 'bg-red-500' : 'bg-cyan-500'}`} style={{ width: `${node.cpuUsage}%` }}></div>
                </div>
              </div>
              
              <div>
                <div className="flex justify-between text-xs text-slate-400 mb-1">
                  <span>Memory ({node.memory})</span>
                  <span>{node.memoryUsage}%</span>
                </div>
                <div className="h-2 bg-slate-900 rounded-full overflow-hidden">
                  <div className={`h-full rounded-full ${node.memoryUsage > 80 ? 'bg-red-500' : 'bg-cyan-500'}`} style={{ width: `${node.memoryUsage}%` }}></div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-slate-800 rounded-xl border border-slate-700 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-700">
          <h3 className="text-lg font-medium text-slate-200 flex items-center gap-2">
            <Cpu size={18} className="text-slate-400" /> Pods Overview
          </h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-400">
            <thead className="text-xs text-slate-500 uppercase bg-slate-900/50">
              <tr>
                <th className="px-4 py-3">Name</th>
                <th className="px-4 py-3">Namespace</th>
                <th className="px-4 py-3">Node</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Restarts</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {mockKubernetesPods.map(pod => (
                <tr key={pod.id} className="hover:bg-slate-800/50 transition-colors">
                  <td className="px-4 py-3 text-slate-300 font-medium">{pod.name}</td>
                  <td className="px-4 py-3">{pod.namespace}</td>
                  <td className="px-4 py-3">{pod.node}</td>
                  <td className="px-4 py-3">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${pod.status === 'Running' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'}`}>
                      {pod.status}
                    </span>
                  </td>
                  <td className="px-4 py-3">{pod.restarts}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
