import React from 'react';
import { Layers, CheckCircle2, Clock } from 'lucide-react';
import { mockComponents } from '@/data/mockData';

export default function DigitalTwinPage() {
  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-slate-100 flex items-center gap-2">
          <Layers className="text-cyan-500" />
          Digital Twin Status
        </h1>
        <p className="text-slate-400 text-sm mt-1">Real-time synchronization state of your infrastructure twin.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-slate-800 rounded-xl p-5 border border-slate-700 shadow-sm flex flex-col items-center justify-center text-center">
          <CheckCircle2 size={48} className="text-emerald-500 mb-3" />
          <h3 className="text-lg font-medium text-slate-200">Twin Synchronized</h3>
          <p className="text-sm text-slate-400 mt-1">All systems are accurately mirrored in real-time.</p>
        </div>

        <div className="bg-slate-800 rounded-xl p-5 border border-slate-700 shadow-sm flex flex-col justify-center">
          <div className="text-sm text-slate-400 mb-1">Tracked Components</div>
          <div className="text-3xl font-semibold text-slate-100">{mockComponents.length}</div>
          <div className="text-xs text-emerald-400 mt-2">+2 discovered today</div>
        </div>

        <div className="bg-slate-800 rounded-xl p-5 border border-slate-700 shadow-sm flex flex-col justify-center">
          <div className="text-sm text-slate-400 mb-1 flex items-center gap-2">
            <Clock size={16} /> Last Snapshot
          </div>
          <div className="text-lg font-medium text-slate-200">Just now</div>
          <div className="text-xs text-slate-500 mt-2">Continuous sync enabled</div>
        </div>
      </div>
      
      <div className="mt-8 bg-slate-800/50 border border-slate-800 rounded-xl p-8 text-center text-slate-400">
        Detailed component inventory and historical state coming soon...
      </div>
    </div>
  );
}
