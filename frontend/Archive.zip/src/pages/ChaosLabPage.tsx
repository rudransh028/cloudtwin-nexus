import React from 'react';
import { Skull, AlertTriangle, Play } from 'lucide-react';

export default function ChaosLabPage() {
  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-slate-100 flex items-center gap-2">
          <Skull className="text-red-400" />
          Chaos Engineering Lab
        </h1>
        <p className="text-slate-400 text-sm mt-1">Inject controlled failures to validate system resilience.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-slate-800 rounded-xl p-6 border border-slate-700 shadow-sm">
          <h3 className="text-lg font-medium text-slate-200 mb-4">Experiment Catalog</h3>
          <div className="space-y-3">
            {[
              { title: 'Pod Terminations', desc: 'Randomly kill pods in specified namespace', impact: 'Medium' },
              { title: 'Network Blackhole', desc: 'Drop 100% of traffic between DB and API', impact: 'High' },
              { title: 'CPU Pressure', desc: 'Consume 100% CPU on target nodes', impact: 'Low' },
            ].map((exp, i) => (
              <div key={i} className="bg-slate-900/50 p-4 rounded-lg border border-slate-800 hover:border-slate-600 transition-colors cursor-pointer group">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="text-sm font-medium text-slate-200 group-hover:text-cyan-400 transition-colors">{exp.title}</h4>
                    <p className="text-xs text-slate-500 mt-1">{exp.desc}</p>
                  </div>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full uppercase font-medium ${
                    exp.impact === 'High' ? 'bg-red-500/20 text-red-400' :
                    exp.impact === 'Medium' ? 'bg-amber-500/20 text-amber-400' : 'bg-blue-500/20 text-blue-400'
                  }`}>
                    {exp.impact}
                  </span>
                </div>
              </div>
            ))}
          </div>
          <button className="w-full mt-4 bg-red-600/20 hover:bg-red-600/30 text-red-400 border border-red-500/30 py-2 rounded-lg text-sm transition-colors flex items-center justify-center gap-2">
            <Play size={16} /> Start Chaos Experiment
          </button>
        </div>

        <div className="bg-slate-800/50 rounded-xl p-6 border border-slate-700 border-dashed flex flex-col items-center justify-center text-center">
          <AlertTriangle size={48} className="text-slate-600 mb-4" />
          <h3 className="text-lg font-medium text-slate-400">No Active Experiments</h3>
          <p className="text-sm text-slate-500 mt-2 max-w-sm">
            Select an experiment from the catalog to begin testing your architecture's resilience in the isolated twin environment.
          </p>
        </div>
      </div>
    </div>
  );
}
