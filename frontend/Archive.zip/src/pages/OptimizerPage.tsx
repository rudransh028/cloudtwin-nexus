import React from 'react';
import { Wand2, CheckCircle2, XCircle } from 'lucide-react';
import { mockArchitectures } from '@/data/mockData';

export default function OptimizerPage() {
  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-slate-100 flex items-center gap-2">
          <Wand2 className="text-indigo-400" />
          Architecture Auto-Optimizer
        </h1>
        <p className="text-slate-400 text-sm mt-1">AI-generated topologies based on your constraints.</p>
      </div>

      <div className="bg-slate-800 rounded-xl p-6 border border-slate-700 shadow-sm mb-6">
        <h3 className="text-sm font-medium text-slate-300 mb-4">Target Constraints</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <label className="text-xs text-slate-500 block mb-1">Max Budget (/mo)</label>
            <input type="text" value="$15,000" readOnly className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-300 focus:outline-none" />
          </div>
          <div>
            <label className="text-xs text-slate-500 block mb-1">Max Latency</label>
            <input type="text" value="50ms" readOnly className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-300 focus:outline-none" />
          </div>
          <div>
            <label className="text-xs text-slate-500 block mb-1">Target SLA</label>
            <input type="text" value="99.99%" readOnly className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-300 focus:outline-none" />
          </div>
          <div>
            <label className="text-xs text-slate-500 block mb-1">Concurrent Users</label>
            <input type="text" value="100,000" readOnly className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-300 focus:outline-none" />
          </div>
        </div>
        <button className="mt-4 bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-lg text-sm transition-colors shadow-lg shadow-indigo-900/20">
          Generate Candidates
        </button>
      </div>

      <h3 className="text-lg font-medium text-slate-200 mb-4">Generated Candidates</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {mockArchitectures.map((arch) => (
          <div key={arch.id} className={`bg-slate-800 rounded-xl p-5 border ${arch.meetsConstraints ? 'border-emerald-500/30' : 'border-slate-700'} shadow-sm relative overflow-hidden`}>
            {arch.meetsConstraints && (
              <div className="absolute top-0 right-0 bg-emerald-500/20 text-emerald-400 text-xs px-3 py-1 rounded-bl-lg font-medium flex items-center gap-1">
                <CheckCircle2 size={12} /> Meets Requirements
              </div>
            )}
            {!arch.meetsConstraints && (
              <div className="absolute top-0 right-0 bg-red-500/20 text-red-400 text-xs px-3 py-1 rounded-bl-lg font-medium flex items-center gap-1">
                <XCircle size={12} /> Fails SLA Constraint
              </div>
            )}
            
            <h4 className="text-lg font-medium text-slate-200 mt-2 mb-4">{arch.name}</h4>
            
            <div className="grid grid-cols-3 gap-4 mb-4">
              <div className="bg-slate-900/50 p-2 rounded border border-slate-800 text-center">
                <div className="text-xs text-slate-500">Cost</div>
                <div className="text-sm font-semibold text-slate-300">${arch.cost}/mo</div>
              </div>
              <div className="bg-slate-900/50 p-2 rounded border border-slate-800 text-center">
                <div className="text-xs text-slate-500">Latency</div>
                <div className="text-sm font-semibold text-slate-300">{arch.latency}ms</div>
              </div>
              <div className="bg-slate-900/50 p-2 rounded border border-slate-800 text-center">
                <div className="text-xs text-slate-500">SLA</div>
                <div className="text-sm font-semibold text-slate-300">{arch.sla}%</div>
              </div>
            </div>
            
            <p className="text-sm text-slate-400 mb-4">{arch.description}</p>
            
            <button className="w-full bg-slate-700 hover:bg-slate-600 text-slate-200 py-2 rounded-lg text-sm transition-colors">
              View Topology Map
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
