import React from 'react';
import { X, Activity, Cpu, Server, AlertCircle } from 'lucide-react';
import { Component } from '@/lib/types';
import { cn } from '@/lib/utils';
import { mockDependencies } from '@/data/mockData';

interface ComponentDetailProps {
  component: Component | null;
  onClose: () => void;
}

export default function ComponentDetail({ component, onClose }: ComponentDetailProps) {
  if (!component) return null;

  const statusColor = {
    healthy: 'text-emerald-400',
    warning: 'text-amber-400',
    critical: 'text-red-400',
    degraded: 'text-amber-400',
  }[component.status] || 'text-slate-400';

  const dependsOn = mockDependencies.filter(d => d.source === component.id);
  const dependedBy = mockDependencies.filter(d => d.target === component.id);

  return (
    <div className="fixed right-0 top-0 h-full w-96 bg-slate-900 border-l border-slate-700 shadow-2xl flex flex-col z-50 transform transition-transform duration-300">
      <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-slate-800/50">
        <div>
          <h2 className="text-lg font-semibold text-slate-100">{component.name}</h2>
          <div className="flex items-center gap-2 mt-1">
            <span className={cn("text-xs font-medium uppercase tracking-wider", statusColor)}>
              {component.status}
            </span>
            <span className="text-xs text-slate-500">•</span>
            <span className="text-xs text-slate-400">{component.type}</span>
            <span className="text-xs text-slate-500">•</span>
            <span className="text-xs text-slate-400">{component.region}</span>
          </div>
        </div>
        <button onClick={onClose} className="p-1 hover:bg-slate-700 rounded-md text-slate-400 transition-colors">
          <X size={20} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        <section>
          <h3 className="text-sm font-medium text-slate-300 mb-3 flex items-center gap-2">
            <Activity size={16} /> Metrics
          </h3>
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-slate-800/50 p-3 rounded-lg border border-slate-800">
              <div className="text-xs text-slate-400 mb-1">CPU Usage</div>
              <div className="text-lg font-semibold text-slate-100">{component.metrics.cpu}%</div>
            </div>
            <div className="bg-slate-800/50 p-3 rounded-lg border border-slate-800">
              <div className="text-xs text-slate-400 mb-1">Memory</div>
              <div className="text-lg font-semibold text-slate-100">{component.metrics.memory}%</div>
            </div>
            <div className="bg-slate-800/50 p-3 rounded-lg border border-slate-800">
              <div className="text-xs text-slate-400 mb-1">Request Rate</div>
              <div className="text-lg font-semibold text-slate-100">{component.metrics.requestRate} req/s</div>
            </div>
            <div className="bg-slate-800/50 p-3 rounded-lg border border-slate-800">
              <div className="text-xs text-slate-400 mb-1">Latency</div>
              <div className="text-lg font-semibold text-slate-100">{component.metrics.latency}ms</div>
            </div>
          </div>
        </section>

        <section>
          <h3 className="text-sm font-medium text-slate-300 mb-3 flex items-center gap-2">
            <Server size={16} /> Dependencies
          </h3>
          <div className="space-y-4">
            <div>
              <div className="text-xs text-slate-400 mb-2">Depends On ({dependsOn.length})</div>
              {dependsOn.length > 0 ? (
                <ul className="space-y-2">
                  {dependsOn.map(d => (
                    <li key={d.id} className="text-sm text-slate-300 bg-slate-800/30 px-2 py-1.5 rounded flex justify-between">
                      <span>{d.target}</span>
                      <span className="text-xs text-slate-500">{d.type}</span>
                    </li>
                  ))}
                </ul>
              ) : <div className="text-xs text-slate-500 italic">None</div>}
            </div>
            <div>
              <div className="text-xs text-slate-400 mb-2">Depended By ({dependedBy.length})</div>
              {dependedBy.length > 0 ? (
                <ul className="space-y-2">
                  {dependedBy.map(d => (
                    <li key={d.id} className="text-sm text-slate-300 bg-slate-800/30 px-2 py-1.5 rounded flex justify-between">
                      <span>{d.source}</span>
                      <span className="text-xs text-slate-500">{d.type}</span>
                    </li>
                  ))}
                </ul>
              ) : <div className="text-xs text-slate-500 italic">None</div>}
            </div>
          </div>
        </section>

        <section>
          <h3 className="text-sm font-medium text-slate-300 mb-3 flex items-center gap-2">
            <AlertCircle size={16} /> Cost
          </h3>
          <div className="bg-slate-800/50 p-3 rounded-lg border border-slate-800 flex justify-between items-center">
            <span className="text-sm text-slate-300">Monthly Cost</span>
            <span className="text-sm font-semibold text-slate-100">${component.cost}</span>
          </div>
        </section>
      </div>
    </div>
  );
}
