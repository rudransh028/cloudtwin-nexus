import React from 'react';
import { Handle, Position } from '@xyflow/react';
import { Server, Database, HardDrive, Wifi, Shield, Box, Users, Container } from 'lucide-react';
import { ComponentType, Status } from '@/lib/types';
import { cn } from '@/lib/utils';

interface ComponentNodeProps {
  data: {
    name: string;
    type: ComponentType;
    status: Status;
    metrics: {
      cpu?: number;
      memory?: number;
      requestRate?: number;
      latency?: number;
      errorRate?: number;
    };
  };
}

export default function ComponentNode({ data }: ComponentNodeProps) {
  const Icon = () => {
    switch (data.type) {
      case 'service': return <Server size={18} />;
      case 'database': return <Database size={18} />;
      case 'storage': return <HardDrive size={18} />;
      case 'load_balancer': return <Wifi size={18} />;
      case 'gateway': return <Shield size={18} />;
      case 'cache': return <Box size={18} />;
      case 'user': return <Users size={18} />;
      case 'pod': return <Container size={18} />;
      default: return <Server size={18} />;
    }
  };

  const statusColor = {
    healthy: 'bg-emerald-500',
    warning: 'bg-amber-500',
    critical: 'bg-red-500',
    degraded: 'bg-amber-500', // Mapping degraded to amber
  }[data.status] || 'bg-slate-500';

  const borderColor = {
    healthy: 'border-emerald-500/50',
    warning: 'border-amber-500/50',
    critical: 'border-red-500/50',
    degraded: 'border-amber-500/50',
  }[data.status] || 'border-slate-700';

  return (
    <div className={cn(
      "relative flex flex-col bg-slate-800 rounded-lg p-3 w-[160px] border shadow-lg transition-all hover:shadow-cyan-500/20",
      borderColor
    )}>
      <Handle type="target" position={Position.Top} className="!bg-slate-500 !w-2 !h-2" />
      
      <div className="flex items-center justify-between mb-2">
        <div className="text-slate-300">
          <Icon />
        </div>
        <div className={cn("w-2 h-2 rounded-full", statusColor)} />
      </div>
      
      <div className="text-sm font-medium text-slate-100 truncate mb-2">
        {data.name}
      </div>
      
      <div className="flex gap-2 text-xs">
        {data.metrics.cpu !== undefined && (
          <div className="bg-slate-900 rounded px-1.5 py-0.5 text-slate-400">
            CPU: {data.metrics.cpu}%
          </div>
        )}
        {data.metrics.latency !== undefined && (
          <div className="bg-slate-900 rounded px-1.5 py-0.5 text-slate-400">
            {data.metrics.latency}ms
          </div>
        )}
      </div>

      <Handle type="source" position={Position.Bottom} className="!bg-slate-500 !w-2 !h-2" />
    </div>
  );
}
