import React from 'react';
import { useLocation } from 'react-router-dom';
import { Search, Bell } from 'lucide-react';
import { useUiStore } from '@/stores/uiStore';

export const TopBar = () => {
  const location = useLocation();
  const { notifications, currentProject } = useUiStore();

  // Basic title extraction from path
  const pathParts = location.pathname.split('/').filter(Boolean);
  const title = pathParts.length > 0 
    ? pathParts[0].charAt(0).toUpperCase() + pathParts[0].slice(1)
    : 'Dashboard';

  return (
    <header className="h-[56px] bg-[#0c1222]/80 backdrop-blur border-b border-slate-800 flex items-center justify-between px-6 sticky top-0 z-10 shrink-0">
      {/* Left side */}
      <div className="flex items-center space-x-4">
        <h1 className="text-lg font-semibold text-slate-100">{title}</h1>
      </div>

      {/* Center - Search */}
      <div className="flex-1 max-w-md px-6 hidden md:block">
        <button className="w-full flex items-center px-4 py-1.5 bg-slate-900/50 hover:bg-slate-800 border border-slate-800 rounded-lg text-sm text-slate-400 transition-colors group">
          <Search className="h-4 w-4 mr-2 text-slate-500 group-hover:text-slate-400" />
          <span className="flex-1 text-left">Search resources, metrics...</span>
          <div className="flex items-center space-x-1">
            <kbd className="px-1.5 py-0.5 rounded bg-slate-800 text-[10px] font-mono text-slate-400">⌘</kbd>
            <kbd className="px-1.5 py-0.5 rounded bg-slate-800 text-[10px] font-mono text-slate-400">K</kbd>
          </div>
        </button>
      </div>

      {/* Right side */}
      <div className="flex items-center space-x-4">
        <div className="hidden sm:flex items-center space-x-2 px-3 py-1">
          <div className="h-2 w-2 rounded-full bg-emerald-500"></div>
          <span className="text-xs font-medium text-emerald-400">Connected</span>
        </div>

        <button className="relative p-2 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition-colors">
          <Bell className="h-5 w-5" />
          {notifications > 0 && (
            <span className="absolute top-1 right-1 h-4 w-4 rounded-full bg-brand-500 border-2 border-[#0c1222] text-[10px] font-bold text-white flex items-center justify-center leading-none">
              {notifications}
            </span>
          )}
        </button>

        <div className="h-8 w-8 rounded-full bg-gradient-to-tr from-brand-600 to-brand-400 flex items-center justify-center text-sm font-bold text-white shadow-sm ring-2 ring-slate-800 overflow-hidden cursor-pointer">
          RP
        </div>
      </div>
    </header>
  );
};
